'''Alias of :mod:`panda3d.interrogatedb`.

.. deprecated:: 1.10.0
   This module has been renamed to :mod:`panda3d.interrogatedb`.
'''

if __debug__:
    print("Warning: panda3d.dtoolconfig is deprecated, use panda3d.interrogatedb instead.")
from .interrogatedb import *
