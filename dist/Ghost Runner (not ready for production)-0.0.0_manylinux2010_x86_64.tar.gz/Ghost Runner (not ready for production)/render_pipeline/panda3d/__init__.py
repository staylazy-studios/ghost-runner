"Python bindings for the Panda3D libraries"

__version__ = '1.10.12'
